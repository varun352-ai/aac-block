'use client';

import { motion } from "framer-motion";
import { Phone, Mail, Package, Blocks, BookOpen } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* Hero Section */}
      <section className="relative flex flex-col items-center justify-center text-center py-20 px-6 bg-gradient-to-br from-blue-50 to-gray-100">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-6xl font-bold text-gray-900"
        >
          Premium AAC Blocks & Mortars
        </motion.h1>
        <p className="mt-4 max-w-2xl text-lg text-gray-600">
          Your trusted dealer & distributor of India’s leading AAC Block brands.
        </p>
        <div className="mt-6 flex flex-wrap gap-4 justify-center">
          <a
            href={`https://wa.me/919582872872?text=Hello, I want a quote on AAC Blocks`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-blue-600 text-white px-6 py-3 rounded-2xl text-lg shadow-md hover:bg-blue-700"
          >
            WhatsApp Us
          </a>
          <a
            href="#contact"
            className="border border-blue-600 text-blue-600 px-6 py-3 rounded-2xl text-lg shadow-md hover:bg-blue-50"
          >
            Get a Quote
          </a>
        </div>
      </section>

      {/* Brands Section */}
      <section className="py-16 px-6 bg-white">
        <h2 className="text-3xl font-bold text-center mb-10">
          Brands We Deal In
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {[
            "BirlaNu (HIL Birla)",
            "Shree Heat Shield",
            "Insta Blocks",
            "JK Lakshmi",
            "Magicrete",
            "RS Green",
            "Renaconn",
            "Conecc",
            "Siporex",
            "UltraTech Xtralite",
            "Biltech",
            "Ecolite",
            "Inframarket",
            "Magna AAC Blocks",
          ].map((brand, idx) => (
            <div key={idx} className="rounded-xl shadow-sm border border-gray-200 hover:shadow-lg transition p-6 text-center font-medium">
              {brand}
            </div>
          ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 px-6 bg-gray-50" id="products">
        <h2 className="text-3xl font-bold text-center mb-10">
          Product Categories
        </h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <div className="rounded-2xl shadow-md border hover:shadow-xl transition p-8 text-center">
            <Blocks className="w-12 h-12 mx-auto text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">AAC Blocks</h3>
            <p className="text-gray-600">
              High strength, lightweight, eco-friendly building blocks.
            </p>
          </div>
          <div className="rounded-2xl shadow-md border hover:shadow-xl transition p-8 text-center">
            <Package className="w-12 h-12 mx-auto text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Block Adhesives</h3>
            <p className="text-gray-600">
              Superior jointing mortars & adhesives for durable construction.
            </p>
          </div>
          <div className="rounded-2xl shadow-md border hover:shadow-xl transition p-8 text-center">
            <BookOpen className="w-12 h-12 mx-auto text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Guides & Blogs</h3>
            <p className="text-gray-600">
              Stay informed with building tips, product comparisons & more.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 px-6 bg-white" id="contact">
        <h2 className="text-3xl font-bold text-center mb-10">
          Get in Touch With Us
        </h2>
        <div className="max-w-2xl mx-auto bg-gray-50 rounded-2xl shadow p-8">
          <form className="space-y-4">
            <input type="text" placeholder="Your Name" className="w-full border rounded-lg p-3" required />
            <input type="email" placeholder="Your Email" className="w-full border rounded-lg p-3" required />
            <input type="tel" placeholder="Your Phone" className="w-full border rounded-lg p-3" required />
            <textarea placeholder="Your Message" className="w-full border rounded-lg p-3" rows={4} required />
            <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded-xl text-lg shadow-md hover:bg-blue-700">
              Send Message
            </button>
          </form>
          <div className="mt-6 text-center text-gray-700 space-y-2">
            <p className="flex items-center justify-center gap-2">
              <Phone className="w-5 h-5" /> +91 9582-872-872
            </p>
            <p className="flex items-center justify-center gap-2">
              <Mail className="w-5 h-5" /> sales@yourcompany.com
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
