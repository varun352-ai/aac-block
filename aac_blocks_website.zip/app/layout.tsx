import './globals.css'

export const metadata = {
  title: 'AAC Blocks Website',
  description: 'Premium AAC Blocks & Mortars',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}